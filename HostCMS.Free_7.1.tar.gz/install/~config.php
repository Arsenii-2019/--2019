<?php

/**
 * Rename to config.php if you want to use the predefined values.
 */

return array(
	'database' => array(
		'host' => 'localhost',
		'username' => 'пользователь_базы',
		'password' => 'пароль',
		'database' => 'имя_базы',
	),
	'license' => array(
		'login' => 'ЛОГИН ПОЛЬЗОВАТЕЛЯ',
		'license' => 'НОМЕР ЛИЦЕНЗИИ',
		'pin' => 'PIN-КОД',
	)
);