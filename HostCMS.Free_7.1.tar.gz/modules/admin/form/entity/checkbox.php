<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Admin forms.
 *
 * * postingUnchecked - добавляет скрытый input со значением 0, передается в случае снятия галочки у checkbox
 *
 * @package HostCMS
 * @subpackage Admin
 * @version 6.x
 * @copyright © 2005-2017, https://www.hostcms.ru
 */
class Admin_Form_Entity_Checkbox extends Skin_Default_Admin_Form_Entity_Checkbox {}