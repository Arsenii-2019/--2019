<?php

defined('HOSTCMS') || exit('HostCMS: access denied.');

/**
 * Admin forms.
 *
 * @package HostCMS
 * @subpackage Admin
 * @version 6.x
 * @copyright © 2005-2017, https://www.hostcms.ru
 */
class Admin_Form_Entity_Code extends Skin_Default_Admin_Form_Entity_Code {}