<?php

$Informationsystem_Controller_Show = Core_Page::instance()->object;

$xslName = $Informationsystem_Controller_Show->item
	? Core_Array::get(Core_Page::instance()->libParams, 'informationsystemItemXsl')
	: Core_Array::get(Core_Page::instance()->libParams, 'informationsystemXsl');

$Informationsystem_Controller_Show->addEntity(
	Core::factory('Core_Xml_Entity')
		->name('ОтображатьСсылкуНаАрхив')->value(0)
)->addEntity(
	Core::factory('Core_Xml_Entity')
		->name('ОтображатьСсылкиНаСледующиеСтраницы')->value(1)
)->addEntity(
	Core::factory('Core_Xml_Entity')
		->name('ТекущаяГруппа')->value($Informationsystem_Controller_Show->group)
)->addEntity(
	Core::factory('Core_Xml_Entity')
		->name('show_comments')->value(
			Core_Array::get(Core_Page::instance()->libParams, 'showComments', 1, 'int')
		)
)->addEntity(
	Core::factory('Core_Xml_Entity')
		->name('show_add_comments')->value(
			Core_Array::get(Core_Page::instance()->libParams, 'showAddComment', 2, 'int')
		)
);

$Informationsystem_Controller_Show
	->tags(TRUE)
	->comments(TRUE);

if ($Informationsystem_Controller_Show->item == 0)
{
	//$Informationsystem_Controller_Show->itemsForbiddenTags(array('text'));

	// Обработка вставки информационного элемента
	if (Core_Array::getPost('submit_question'))
	{
		$Informationsystem_Controller_Show->cache(FALSE);

		$siteuser_id = 0;
		if (Core::moduleIsActive('siteuser'))
		{
			$oSiteuser = Core_Entity::factory('Siteuser')->getCurrent();

			if ($oSiteuser)
			{
				$siteuser_id = $oSiteuser->id;
			}
		}

		$oInformationsystem_Item = Core_Entity::factory('Informationsystem_Item');
		$oInformationsystem_Item->informationsystem_group_id = $Informationsystem_Controller_Show->group;
		$oInformationsystem_Item->active = Core_Page::instance()->libParams['addedItemActive'];
		$oInformationsystem_Item->path = '';

		$subject = nl2br(strip_tags(Core_Array::getPost('subject', '', 'str')));
		$text = strip_tags(Core_Array::getPost('text', '', 'str'));
		$oInformationsystem_Item->name = strlen($subject) > 0 ? $subject : '<Без темы>';
		$oInformationsystem_Item->text = nl2br($text);
		$oInformationsystem_Item->siteuser_id = $siteuser_id;

		$author = strip_tags(Core_Array::getPost('author', '', 'str'));
		$email = strip_tags(Core_Array::getPost('email', '', 'str'));

		$oInformationsystem = $Informationsystem_Controller_Show->getEntity();
		$oInformationsystemItems = $oInformationsystem->Informationsystem_Items;
		$oInformationsystemItems->queryBuilder()
			->where('ip', '=', Core::getClientIp())
			->orderBy('id', 'DESC')
			->limit(1);

		$aLastInformationsystemItem = $oInformationsystemItems->findAll();

		if (!isset($aLastInformationsystemItem[0]) || time() < Core_Date::sql2timestamp($oInformationsystem_Item->datetime) + ADD_COMMENT_DELAY)
		{
			if ($oInformationsystem->use_captcha == 0 || $siteuser_id > 0 || Core_Captcha::valid(Core_Array::getPost('captcha_id', '', 'str'), Core_Array::getPost('captcha', '', 'str')))
			{
				$oInformationsystem->add($oInformationsystem_Item);

				// Вставляем в дополнительные свойства автора
				$oProperty = Core_Entity::factory('Property')->find(Core_Page::instance()->libParams['authorPropertyId']);

				if (!is_null($oProperty->id) && $author)
				{
					$oValue = $oProperty->createNewValue($oInformationsystem_Item->id);
					$oValue->value = $author;
					$oValue->save();
				}

				// Вставляем в дополнительные свойства email
				$oProperty = Core_Entity::factory('Property')->find(Core_Page::instance()->libParams['emailPropertyId']);

				if (!is_null($oProperty->id) && $email)
				{
					$oValue = $oProperty->createNewValue($oInformationsystem_Item->id);
					$oValue->value = $email;
					$oValue->save();
				}

				// Если пользователь зерегистрирован, получаем информацию
				if ($siteuser_id)
				{
					$author = $oSiteuser->name && $oSiteuser->surname
						? $oSiteuser->name . ' ' .	$oSiteuser->surname
						: $oSiteuser->login;

					$email = $oSiteuser->email;
				}

				ob_start();
				if ($oInformationsystem_Item->active == 0)
				{
					?>
					<p>Благодарим Вас, <?php echo htmlspecialchars($author)?>!
					<br />Ваша запись принята. После проверки администратором она станет доступной!
					</p>
					<?php
				}
				else
				{
					?>
					<p>Благодарим Вас, <?php echo htmlspecialchars($author)?>!
					<br />Ваша запись принята и опубликована!
					</p>
					<?php
				}
				$Informationsystem_Controller_Show->addEntity(
					Core::factory('Core_Xml_Entity')
						->name('message')->value(ob_get_clean())
				);

				// Отправка письма администратору
				$message = "Доброе время суток, уважаемый Администратор!\n\nНа сайт, поддерживаемый системой управления сайтом HostCMS, была добавлена запись:\n";
				$message .= "Автор: " . $author . "\n";
				$message .= "E-mail: " . $email . "\n";
				$message .= "Тема: {$oInformationsystem_Item->name}\n";
				$message .= "Информационная система: ".$oInformationsystem->name."\n";
				$message .= "Дата: " . Core_Date::sql2datetime($oInformationsystem_Item->datetime) . "\n";
				$message .= "IP-адрес: " . $oInformationsystem_Item->ip . "\n";
				$message .= "Вопрос: " . $oInformationsystem_Item->text;

				$aFrom = array_map('trim', explode(',', EMAIL_TO));

				Core_Mail::instance()
					->to(EMAIL_TO)
					->from($aFrom[0])
					->header('Reply-To', Core_Valid::email($email)
						? $email
						: $aFrom[0]
					)
					->subject('Добавление информационного элемента')
					->message($message)
					->contentType('text/plain')
					->send();
			}
			else
			{
				$Informationsystem_Controller_Show->addEntity(
					Core::factory('Core_Xml_Entity')
						->name('error')->value('Введен неверный код подтверждения!')
				)
				->addEntity(
					Core::factory('Core_Xml_Entity')->name('adding_item')
					->addEntity(
						Core::factory('Core_Xml_Entity')->name('author')->value($author)
					)->addEntity(
						Core::factory('Core_Xml_Entity')->name('email')->value($email)
					)->addEntity(
						Core::factory('Core_Xml_Entity')->name('subject')->value($subject)
					)->addEntity(
						Core::factory('Core_Xml_Entity')->name('text')->value($text)
					)
				);
			}
		}
		else
		{
			$Informationsystem_Controller_Show->addEntity(
					Core::factory('Core_Xml_Entity')
						->name('error')->value('Запись не может быть добавлена, т.к. прошло мало времени с момента Вашего последнего добавления вопроса!')
				);
		}
	}
}
else
{
	if (Core_Array::getPost('add_comment') && Core_Array::get(Core_Page::instance()->libParams, 'showAddComment') != 0)
	{
		$Informationsystem_Controller_Show->cache(FALSE);

		$oLastComment = Core_Entity::factory('Comment')->getLastCommentByIp(
			Core::getClientIp()
		);

		$oXmlCommentTag = Core::factory('Core_Xml_Entity')
			->name('document');

		$siteuser_id = 0;
		if (Core::moduleIsActive('siteuser'))
		{
			$oSiteuser = Core_Entity::factory('Siteuser')->getCurrent();

			if ($oSiteuser)
			{
				$siteuser_id = $oSiteuser->id;
			}
		}

		$oComment = Core_Entity::factory('Comment');

		$allowable_tags = '<b><strong><i><em><br><p><u><strike><ul><ol><li>';
		$oComment->parent_id = Core_Array::getPost('parent_id', 0, 'int');
		$oComment->active = Core_Array::get(Core_Page::instance()->libParams, 'addedCommentActive', 1) == 1 ? 1 : 0;
		$oComment->author = Core_Str::stripTags(Core_Array::getPost('author', '', 'str'));
		$oComment->email = Core_Str::stripTags(Core_Array::getPost('email', '', 'str'));
		$oComment->grade = Core_Array::getPost('grade', 0, 'int');
		$oComment->subject = Core_Str::stripTags(Core_Array::getPost('subject', '', 'str'));
		$oComment->text = nl2br(Core_Str::stripTags(Core_Array::getPost('text', '', 'str'), $allowable_tags));
		$oComment->siteuser_id = $siteuser_id;

		$oInformationsystem_Item = Core_Entity::factory('Informationsystem_Item', $Informationsystem_Controller_Show->item);

		$oXmlCommentTag
			->addEntity($oComment)
			->addEntity($oInformationsystem_Item);

		if (is_null($oLastComment) || time() > Core_Date::sql2timestamp($oLastComment->datetime) + ADD_COMMENT_DELAY)
		{
			$oInformationsystem = $Informationsystem_Controller_Show->getEntity();

			if ($oInformationsystem->use_captcha == 0 || $siteuser_id > 0 || Core_Captcha::valid(Core_Array::getPost('captcha_id', '', 'str'), Core_Array::getPost('captcha', '', 'str')))
			{
				$oComment->save();

				$oComment
					->dateFormat($oInformationsystem->format_date)
					->dateTimeFormat($oInformationsystem->format_datetime);

				$oInformationsystem_Item->add($oComment)->clearCache();

				$oXmlCommentTag->addEntity($oInformationsystem);

				// Отправка письма администратору
				$sText = Xsl_Processor::instance()
					->xml($oXmlCommentTag->getXml())
					->xsl(Core_Entity::factory('Xsl')->getByName(Core_Array::get(Core_Page::instance()->libParams, 'addCommentAdminMailXsl')))
					->process();

				Core_Mail::instance()
					->to(EMAIL_TO)
					->from(Core_Valid::email($oComment->email)
						? $oComment->email
						: EMAIL_TO
					)
					->subject(Core::_('Informationsystem.comment_mail_subject'))
					->message(trim($sText))
					->contentType(Core_Array::get(Core_Page::instance()->libParams, 'commentMailNoticeType', 0) == 0
						? 'text/plain'
						: 'text/html'
					)
					->send();
			}
			else
			{
				$oXmlCommentTag->addEntity(Core::factory('Core_Xml_Entity')
					->name('error_captcha')->value(1)
				);

				$oComment->text = Core_Str::br2nl($oComment->text);
				$Informationsystem_Controller_Show->addEntity($oComment);
			}
		}
		else
		{
			$oXmlCommentTag->addEntity(Core::factory('Core_Xml_Entity')
				->name('error_time')->value(1)
			);

			$oComment->text = Core_Str::br2nl($oComment->text);
			$Informationsystem_Controller_Show->addEntity($oComment);
		}

		// Результат добавления комментария
		$xsl_result = Xsl_Processor::instance()
			->xml($oXmlCommentTag->getXml())
			->xsl(Core_Entity::factory('Xsl')->getByName(
				Core_Array::get(Core_Page::instance()->libParams, 'addCommentNoticeXsl'))
			)
			->process();

		$Informationsystem_Controller_Show->addEntity(
			Core::factory('Core_Xml_Entity')
				->name('message')->value($xsl_result)
		);
	}
}

// В корне выводим из всех групп
/*if ($Informationsystem_Controller_Show->group == 0)
{
	$Informationsystem_Controller_Show->group(FALSE);
}*/

$Informationsystem_Controller_Show
	->xsl(
		Core_Entity::factory('Xsl')->getByName($xslName)
	)
	->itemsProperties(TRUE)
	->show();