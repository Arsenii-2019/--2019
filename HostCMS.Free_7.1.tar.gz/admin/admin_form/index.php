<?php
/**
 * Admin forms.
 *
 * @package HostCMS
 * @version 7.x
 * @copyright © 2005-2026, https://www.hostcms.ru
 */
require_once('../../bootstrap.php');

// Код формы
$iAdmin_Form_Id = 1;
$sAdminFormAction = '/{admin}/admin_form/index.php';
$oAdmin_Form = Core_Entity::factory('Admin_Form', $iAdmin_Form_Id);

if (Core_Auth::logged())
{
	// Контроллер формы
	$oAdmin_Form_Controller = Admin_Form_Controller::create($oAdmin_Form);

	$oAdmin_Form_Controller->formSettings();

	if (!is_null(Core_Array::getPost('lock')))
	{
		$aReturn = array(
			'id' => 0,
			'status' => 'error'
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'intval');
		$dataset = Core_Array::getPost('dataset', 0, 'intval');
		$entity_id = Core_Array::getPost('entity_id', 0, 'intval');

		if ($admin_form_id)
		{
			try {
				$oAdmin_Form_Lock = Admin_Form_Lock_Controller::lock($admin_form_id, $dataset, $entity_id);

				$aReturn = array(
					'id' => $oAdmin_Form_Lock->id,
					'status' => 'success'
				);
			}
			catch (Exception $e)
			{
				$aReturn = array(
					'status' => 'error'
				);
			}
		}

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('show_locked')))
	{
		$aReturn = array(
			'id' => 0,
			'text' => '',
			'status' => 'error'
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'intval');
		$dataset = Core_Array::getPost('dataset', 0, 'intval');
		$entity_id = Core_Array::getPost('entity_id', 0, 'intval');

		$oAdmin_Form_Locks = Core_Entity::factory('Admin_Form_Lock');
		$oAdmin_Form_Locks->queryBuilder()
			->where('admin_form_locks.admin_form_id', '=', $admin_form_id)
			->where('admin_form_locks.dataset', '=', $dataset)
			->where('admin_form_locks.entity_id', '=', $entity_id);

		$oAdmin_Form_Lock = $oAdmin_Form_Locks->getLast(FALSE);

		if (!is_null($oAdmin_Form_Lock))
		{
			$oUser = Core_Auth::getCurrentUser();
			$oUser_Locked = $oAdmin_Form_Lock->User;

			if ($oUser->id != $oUser_Locked->id)
			{
				if (Core_Date::sql2timestamp($oAdmin_Form_Lock->datetime) + 600 >= time())
				{
					$text = '<div class="alert alert-danger admin-form-locked"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><i class="fa-fw fa-solid fa-ban"></i> ' . Core::_('Admin_Form.form_locked', Core_Date::sql2datetime($oAdmin_Form_Lock->datetime), $oUser_Locked->login) . '</div>';

					$aReturn = array(
						'id' => $oAdmin_Form_Lock->id,
						'text' => $text,
						'status' => 'success'
					);
				}
				else
				{
					$oAdmin_Form_Lock->delete();
				}
			}
		}

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('delete_lock')))
	{
		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'intval');
		$dataset = Core_Array::getPost('dataset', 0, 'intval');
		$entity_id = Core_Array::getPost('entity_id', 0, 'intval');

		Admin_Form_Lock_Controller::unlock($admin_form_id, $dataset, $entity_id);

		$aReturn = array(
			'status' => 'success'
		);

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('autosave')))
	{
		$aReturn = array(
			'id' => 0,
			'status' => 'error'
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'intval');
		$dataset = Core_Array::getPost('dataset', 0, 'intval');
		$entity_id = Core_Array::getPost('entity_id', 0, 'intval');
		//$prev_entity_id = Core_Array::getPost('prev_entity_id', 0, 'intval');
		$json = Core_Array::getPost('json', '', 'strval');

		if (strval($json))
		{
			try {
				// Произошло сохранение с присвоением ID
				$oAdmin_Form_Autosave = /*$prev_entity_id == 0 && $entity_id
					? Core_Entity::factory('Admin_Form_Autosave')->getObject($admin_form_id, $dataset, $prev_entity_id)
					: */Core_Entity::factory('Admin_Form_Autosave')->getObject($admin_form_id, $dataset, $entity_id);

				if (is_null($oAdmin_Form_Autosave))
				{
					$oAdmin_Form_Autosave = Core_Entity::factory('Admin_Form_Autosave');
					$oAdmin_Form_Autosave->admin_form_id = $admin_form_id;
					$oAdmin_Form_Autosave->dataset = $dataset;
					$oAdmin_Form_Autosave->entity_id = $entity_id;
				}

				$oAdmin_Form_Autosave->json = $json;
				$oAdmin_Form_Autosave->datetime = Core_Date::timestamp2sql(time());
				$oAdmin_Form_Autosave->save();

				// Произошла блокировка
				Admin_Form_Lock_Controller::lock($admin_form_id, $dataset, $entity_id);

				$aReturn = array(
					'id' => $oAdmin_Form_Autosave->id,
					'status' => 'success'
				);
			}
			catch (Exception $e)
			{
				$aReturn = array(
					'status' => 'error'
				);
			}
		}

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('show_autosave')))
	{
		$aReturn = array(
			'id' => 0,
			'json' => '',
			'text' => '',
			'status' => 'error'
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'intval');
		$dataset = Core_Array::getPost('dataset', 0, 'intval');
		$entity_id = Core_Array::getPost('entity_id', 0, 'intval');

		$oAdmin_Form_Autosave = Core_Entity::factory('Admin_Form_Autosave')->getObject($admin_form_id, $dataset, $entity_id);

		if (!is_null($oAdmin_Form_Autosave))
		{
			$text = '<div class="alert alert-info admin-form-autosave"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><i class="fa-fw fa-solid fa-triangle-exclamation"></i> ' . Core::_('Admin_Form_Autosave.autosave_success') . ' <a href="#">' . Core::_('Admin_Form_Autosave.autosave_link') . '</a></div>';

			$aReturn = array(
				'id' => $oAdmin_Form_Autosave->id,
				'json' => $oAdmin_Form_Autosave->json,
				'text' => $text,
				'status' => 'success'
			);
		}

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('delete_autosave')))
	{
		$aReturn = array(
			'status' => 'error'
		);

		$admin_form_autosave_id = Core_Array::getPost('admin_form_autosave_id', 0, 'intval');

		$oAdmin_Form_Autosave = Core_Entity::factory('Admin_Form_Autosave')->getById($admin_form_autosave_id);

		if (!is_null($oAdmin_Form_Autosave))
		{
			$oAdmin_Form_Autosave->delete();

			$aReturn['status'] = 'success';
		}

		Core::showJson($aReturn);
	}

	if (!is_null(Core_Array::getPost('showAdminFormSettingsModal')))
	{
		$aJSON = array(
			'html' => ''
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'int');
		$site_id = Core_Array::getPost('site_id', 0, 'int');
		$modelsNames = Core_Array::getPost('modelsNames', '', 'trim');

		$oAdmin_FormTmp = Core_Entity::factory('Admin_Form')->getById($admin_form_id);
		$oUser = Core_Auth::getCurrentUser();

		if (!is_null($oAdmin_FormTmp) && !is_null($oUser))
		{
			$oAdmin_Language = $oAdmin_Form_Controller->getAdminLanguage();

			$oAdmin_Word_Value = $oAdmin_FormTmp->Admin_Word->getWordByLanguage($oAdmin_Language->id);

			$formName = $oAdmin_Word_Value ? $oAdmin_Word_Value->name : '';
			ob_start();
			?>
			<div class="modal fade" id="adminFormSettingsModal<?php echo $oAdmin_FormTmp->id?>" tabindex="-1" role="dialog" aria-labelledby="adminFormSettingsModalLabel">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content no-padding-bottom">
						<form action="<?php echo Admin_Form_Controller::correctBackendPath("/{admin}/admin_form/index.php")?>" method="POST">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title"><?php echo Core::_('Admin_Form.setting_modal_title', $formName)?></h4>
							</div>
							<div class="modal-body">
								<div class="row margin-bottom-10 admin-form-settings-modal">
									<?php
										$aAvailableFields = $oAdmin_FormTmp->getAvailableFieldsForUser($oUser->id);

										$aAdmin_Form_Fields = $oAdmin_FormTmp->Admin_Form_Fields->getAllByView(1, FALSE, '!=');

										if (Core::moduleIsActive('field'))
										{
											$aFields = Admin_Form_Controller::getFields($site_id, explode(',', $modelsNames));
											$aAdmin_Form_Fields = array_merge($aAdmin_Form_Fields, $aFields);
										}

										foreach ($aAdmin_Form_Fields as $oAdmin_Form_Field)
										{
											$fieldName = method_exists($oAdmin_Form_Field, 'getCaption')
												? htmlspecialchars($oAdmin_Form_Field->getCaption($oAdmin_Language->id))
												: $oAdmin_Form_Field->caption;

											if ($fieldName == '' && $oAdmin_Form_Field->ico != '')
											{
												$fieldName = '<i class="' . htmlspecialchars($oAdmin_Form_Field->ico) . '"></i>';
											}

											// Нет названия, нет иконки - выводим тире
											$fieldName == '' && $fieldName = '—';

											$bChecked = isset($aAvailableFields[$oAdmin_Form_Field->id])
												? TRUE
												: !count($aAvailableFields) && $oAdmin_Form_Field->show_by_default;

											$class = $bChecked
												? ' admin-field-checked'
												: '';

											strpos($oAdmin_Form_Field->id, 'uf_') === 0
												&& $class .= ' admin-field-userfield';

											Admin_Form_Entity::factory('Checkbox')
												->caption($fieldName)
												->divAttr(array('class' => 'form-group col-xs-12 col-sm-4' . $class))
												->name('admin_form_field' . $oAdmin_Form_Field->id)
												->value(1)
												->controller($oAdmin_Form_Controller)
												->checked($bChecked)
												->data('id', $oAdmin_Form_Field->id)
												->onclick('$.selectAdminFormSetting(this)')
												->execute();
										}
									?>
								</div>
							</div>
							<div class="modal-footer">
								<div class="pull-left">
									<span class="admin-form-field-check admin-form-field-check-all sky margin-right-5" onclick="$.selectAdminFormSettings(<?php echo $oAdmin_FormTmp->id?>, 1)"><?php echo Core::_('Admin_form.select_all')?></span>
									<span class="admin-form-field-check" onclick="$.selectAdminFormSettings(<?php echo $oAdmin_FormTmp->id?>, 0)"><?php echo Core::_('Admin_form.disable_all')?></span>
								</div>

								<button type="button" class="btn btn-success" onclick="mainFormLocker.unlock(); <?php echo $oAdmin_Form_Controller->clearChecked()->getAdminSendForm(array('action' => 'applyFormFieldSettings', 'additionalParams' => 'hostcms[checked][0][' . $oAdmin_FormTmp->id . ']=1&site_id=' . $site_id .'&modelsNames=' . $modelsNames))?>"><?php echo Core::_('Admin_Form.apply')?></button>
							</div>
						</form>
					</div>
				</div>
			</div>
			<?php
			$aJSON['html'] = ob_get_clean();
		}

		Core::showJson($aJSON);
	}

	if (!is_null(Core_Array::getPost('saveAdminFieldWidth')))
	{
		$aJSON = array(
			'status' => 'error'
		);

		$admin_form_id = Core_Array::getPost('admin_form_id', 0, 'int');
		$admin_form_field_id = Core_Array::getPost('admin_form_field_id', 0, 'trim');
		$width = Core_Array::getPost('width', 0, 'int');

		$oAdmin_FormTmp = Core_Entity::factory('Admin_Form')->getById($admin_form_id);

		$oUser = Core_Auth::getCurrentUser();

		if ($width && !is_null($oAdmin_FormTmp) && !is_null($oUser))
		{
			// Если не было полей для формы сохранено, то при создании не затрагиваем пользовательские поля
			$aAdmin_Form_Field_Settings = $oAdmin_FormTmp->Admin_Form_Field_Settings->getAllByUser_id($oUser->id, FALSE);
			if (!count($aAdmin_Form_Field_Settings))
			{
				$aAdmin_Form_Fields = $oAdmin_FormTmp->Admin_Form_Fields->getAllByshow_by_default(1, FALSE);
				foreach ($aAdmin_Form_Fields as $oTmpAdmin_Form_Field)
				{
					$oAdmin_Form_Field_Setting = Core_Entity::factory('Admin_Form_Field_Setting');
					$oAdmin_Form_Field_Setting->admin_form_id = $oAdmin_FormTmp->id;
					$oAdmin_Form_Field_Setting->user_id = $oUser->id;
					$oAdmin_Form_Field_Setting->admin_form_field_id = $oTmpAdmin_Form_Field->id;
					$oAdmin_Form_Field_Setting->field_id = 0;
					$oAdmin_Form_Field_Setting->save();
				}
			}

			$oAdmin_Form_Field_Settings = $oAdmin_FormTmp->Admin_Form_Field_Settings;
			$oAdmin_Form_Field_Settings->queryBuilder()
					->where('user_id', '=', $oUser->id)
					->clearOrderBy()
					->orderBy('id', 'DESC')
					->limit(1);

			$bUserField = strpos($admin_form_field_id, 'uf_') === 0;

			$bUserField
				? $oAdmin_Form_Field_Settings->queryBuilder()->where('field_id', '=', intval(filter_var($admin_form_field_id, FILTER_SANITIZE_NUMBER_INT)))
				: $oAdmin_Form_Field_Settings->queryBuilder()->where('admin_form_field_id', '=', $admin_form_field_id);

			$aAdmin_Form_Field_Settings = $oAdmin_Form_Field_Settings->findAll(FALSE);

			if (isset($aAdmin_Form_Field_Settings[0]))
			{
				$oAdmin_Form_Field_Setting = $aAdmin_Form_Field_Settings[0];
			}
			else
			{
				$oAdmin_Form_Field_Setting = Core_Entity::factory('Admin_Form_Field_Setting');
				$oAdmin_Form_Field_Setting->admin_form_id = $oAdmin_FormTmp->id;
				$oAdmin_Form_Field_Setting->user_id = $oUser->id;

				if ($bUserField)
				{
					$oAdmin_Form_Field_Setting->field_id = intval(filter_var($admin_form_field_id, FILTER_SANITIZE_NUMBER_INT));
					$oAdmin_Form_Field_Setting->admin_form_field_id = 0;
				}
				else
				{
					$oAdmin_Form_Field_Setting->admin_form_field_id = $admin_form_field_id;
					$oAdmin_Form_Field_Setting->field_id = 0;
				}
			}

			$oAdmin_Form_Field_Setting->width = $width;
			$oAdmin_Form_Field_Setting->save();

			$aJSON['status'] = 'success';
		}

		Core::showJson($aJSON);
	}

	if ($oAdmin_Form_Controller->getAction() == 'applyFormFieldSettings')
	{
		$oUser = Core_Auth::getCurrentUser();

		$oAdmin_FormTmp = NULL;

		$aChecked = $oAdmin_Form_Controller->getChecked();

		if (!is_null($oUser) && isset($aChecked[0]))
		{
			$key = key($aChecked[0]);
			$oAdmin_FormTmp = Core_Entity::factory('Admin_Form')->getById($key);

			if (!is_null($oAdmin_FormTmp))
			{
				$aExistFormFieldSettings = array();

				$oAdmin_Form_Field_Settings = $oAdmin_FormTmp->Admin_Form_Field_Settings;
				$oAdmin_Form_Field_Settings->queryBuilder()
					->where('user_id', '=', $oUser->id);

				$aAdmin_Form_Field_Settings = $oAdmin_Form_Field_Settings->findAll(FALSE);
				foreach ($aAdmin_Form_Field_Settings as $oAdmin_Form_Field_Setting)
				{
					$oAdmin_Form_Field_Setting->admin_form_field_id
						&& $aExistFormFieldSettings[$oAdmin_Form_Field_Setting->admin_form_field_id] = $oAdmin_Form_Field_Setting;

						Core::moduleIsActive('field') && $oAdmin_Form_Field_Setting->field_id
						&& $aExistFormFieldSettings['uf_' . $oAdmin_Form_Field_Setting->field_id] = $oAdmin_Form_Field_Setting;
				}

				$aAdmin_Form_Fields = $oAdmin_FormTmp->Admin_Form_Fields->findAll(FALSE);

				if (Core::moduleIsActive('field'))
				{
					$site_id = Core_Array::getGet('site_id', 0, 'int');
					$modelsNames = Core_Array::getGet('modelsNames', '', 'trim');

					$aFields = Admin_Form_Controller::getFields($site_id, explode(',', $modelsNames));
					$aAdmin_Form_Fields = array_merge($aAdmin_Form_Fields, $aFields);
				}

				foreach ($aAdmin_Form_Fields as $oAdmin_Form_Field)
				{
					if (isset($_POST['admin_form_field' . $oAdmin_Form_Field->id]))
					{
						if (isset($aExistFormFieldSettings[$oAdmin_Form_Field->id]))
						{
							unset($aExistFormFieldSettings[$oAdmin_Form_Field->id]);
						}
						else
						{
							// Создаем новый
							$oAdmin_Form_Field_Setting = Core_Entity::factory('Admin_Form_Field_Setting');
							$oAdmin_Form_Field_Setting->admin_form_id = $oAdmin_FormTmp->id;
							$oAdmin_Form_Field_Setting->user_id = $oUser->id;

							if (strpos($oAdmin_Form_Field->id, 'uf_') !== FALSE)
							{
								$field_id = intval(filter_var($oAdmin_Form_Field->id, FILTER_SANITIZE_NUMBER_INT));
								$oAdmin_Form_Field_Setting->field_id = $field_id;
								$oAdmin_Form_Field_Setting->admin_form_field_id = 0;
							}
							else
							{
								$oAdmin_Form_Field_Setting->admin_form_field_id = $oAdmin_Form_Field->id;
								$oAdmin_Form_Field_Setting->field_id = 0;
							}

							$oAdmin_Form_Field_Setting->save();
						}
					}
				}

				// Удаляем оставшиеся, которые не были отмечены
				foreach ($aExistFormFieldSettings as $oAdmin_Form_Field_Setting)
				{
					$oAdmin_Form_Field_Setting->delete();
				}

				$content = "<script>$(function() {
					$('#adminFormSettingsModal{$oAdmin_FormTmp->id}').modal('hide');
					mainFormLocker.unlock();
					$.loadingScreen('show');
					$('#id_content #refresh-toggler').click();
				});</script>";
			}
			else
			{
				$content = '';
			}

			Core::showJson(array(
				'error' => $content,
				'form_html' => '',
				'title' => ''
			));
		}
	}
}

Core_Auth::authorization($sModule = 'admin_form');

// Контроллер формы
$oAdmin_Form_Controller = Admin_Form_Controller::create($oAdmin_Form);
$oAdmin_Form_Controller
	->module(Core_Module_Abstract::factory($sModule))
	->setUp()
	->path($sAdminFormAction)
	->title(Core::_('Admin_Form.show_forms_title'))
	->pageTitle(Core::_('Admin_Form.show_forms_title'));

// Меню формы
$oAdmin_Form_Entity_Menus = Admin_Form_Entity::factory('Menus');

$sLanguagePath = '/{admin}/admin_form/language/index.php';

// Элементы меню
$oAdmin_Form_Entity_Menus->add(
	Admin_Form_Entity::factory('Menu')
		->name(Core::_('Admin_Form.show_form_menu_admin_forms_top1'))
		->icon('fa-solid fa-plus')
		->href(
			$oAdmin_Form_Controller->getAdminActionLoadHref(array('path' => $oAdmin_Form_Controller->getPath(), 'action' => 'edit', 'datasetKey' => 0, 'datasetValue' => 0))
		)
		->onclick(
			$oAdmin_Form_Controller->getAdminActionLoadAjax(array('path' => $oAdmin_Form_Controller->getPath(), 'action' => 'edit', 'datasetKey' => 0, 'datasetValue' => 0))
		)
)->add(
	Admin_Form_Entity::factory('Menu')
		->name(Core::_('Admin_Form.show_form_menu_admin_forms_top2'))
		->icon('fa-solid fa-flag')
		->href(
			$oAdmin_Form_Controller->getAdminLoadHref(array('path' => $sLanguagePath))

		)
		->onclick(
			$oAdmin_Form_Controller->getAdminLoadAjax(array('path' => $sLanguagePath))
		)
);

// Добавляем все меню контроллеру
$oAdmin_Form_Controller->addEntity($oAdmin_Form_Entity_Menus);

// Глобальный поиск
$additionalParams = '';

$sGlobalSearch = Core_Array::getGet('globalSearch', '', 'trim');

$oAdmin_Form_Controller->addEntity(
	Admin_Form_Entity::factory('Code')
		->html('
			<div class="row search-field margin-bottom-20">
				<div class="col-xs-12">
					<form action="' . $oAdmin_Form_Controller->getPath() . '" method="GET">
						<input type="text" name="globalSearch" class="form-control" placeholder="' . Core::_('Admin.placeholderGlobalSearch') . '" value="' . htmlspecialchars($sGlobalSearch) . '" />
						<i class="fa-solid fa-circle-xmark no-margin" onclick="' . $oAdmin_Form_Controller->getAdminLoadAjax($oAdmin_Form_Controller->getPath(), '', '', $additionalParams) . '"></i>
						<button type="submit" class="btn btn-default global-search-button" onclick="' . $oAdmin_Form_Controller->getAdminSendForm('', '', $additionalParams) . '"><i class="fa-solid fa-magnifying-glass fa-fw"></i></button>
					</form>
				</div>
			</div>
		')
);

$sGlobalSearch = str_replace(' ', '%', Core_DataBase::instance()->escapeLike($sGlobalSearch));

// Элементы строки навигации
$oAdmin_Form_Entity_Breadcrumbs = Admin_Form_Entity::factory('Breadcrumbs');

// Элементы строки навигации
$oAdmin_Form_Entity_Breadcrumbs->add(
	Admin_Form_Entity::factory('Breadcrumb')
		->name(Core::_('Admin_Form.show_form_fields_menu_admin_forms'))
		->href(
			$oAdmin_Form_Controller->getAdminLoadHref(array('path' => $oAdmin_Form_Controller->getPath()))
		)
		->onclick(
			$oAdmin_Form_Controller->getAdminLoadAjax(array('path' => $oAdmin_Form_Controller->getPath()))
	)
);

// Добавляем все хлебные крошки контроллеру
$oAdmin_Form_Controller->addEntity($oAdmin_Form_Entity_Breadcrumbs);

// Действие редактирования
$oAdmin_Form_Action = $oAdmin_Form->Admin_Form_Actions->getByName('edit');

if ($oAdmin_Form_Action && $oAdmin_Form_Controller->getAction() == 'edit')
{
	$oAdmin_Form_Controller_Edit = Admin_Form_Action_Controller::factory(
		'Admin_Form_Controller_Edit', $oAdmin_Form_Action
	);

	$oAdmin_Form_Controller_Edit
		->addEntity($oAdmin_Form_Entity_Breadcrumbs);

	// Добавляем типовой контроллер редактирования контроллеру формы
	$oAdmin_Form_Controller->addAction($oAdmin_Form_Controller_Edit);
}

// Действие "Применить"
$oAdminFormActionApply = $oAdmin_Form->Admin_Form_Actions->getByName('apply');

if ($oAdminFormActionApply && $oAdmin_Form_Controller->getAction() == 'apply')
{
	$oAdmin_FormControllerApply = Admin_Form_Action_Controller::factory(
		'Admin_Form_Action_Controller_Type_Apply', $oAdminFormActionApply
	);

	// Добавляем типовой контроллер редактирования контроллеру формы
	$oAdmin_Form_Controller->addAction($oAdmin_FormControllerApply);
}

// Действие "Копировать"
$oAdminFormActionCopy = $oAdmin_Form->Admin_Form_Actions->getByName('copy');

if ($oAdminFormActionCopy && $oAdmin_Form_Controller->getAction() == 'copy')
{
	$oControllerCopy = Admin_Form_Action_Controller::factory(
		'Admin_Form_Action_Controller_Type_Copy', $oAdminFormActionCopy
	);

	// Добавляем типовой контроллер редактирования контроллеру формы
	$oAdmin_Form_Controller->addAction($oControllerCopy);
}

// Источник данных 0
$oAdmin_Form_Dataset = new Admin_Form_Dataset_Entity(
	Core_Entity::factory('Admin_Form')
);

// Доступ только к своим
$oUser = Core_Auth::getCurrentUser();
!$oUser->superuser && $oUser->only_access_my_own
	&& $oAdmin_Form_Dataset->addUserConditions();

$oAdmin_Form_Dataset
	->addCondition(array('select' => array('admin_forms.*', array('admin_word_values.name', 'name'))))
	->addCondition(array('leftJoin' => array('admin_words', 'admin_forms.admin_word_id', '=', 'admin_words.id')))
	->addCondition(array('leftJoin' => array('admin_word_values', 'admin_words.id', '=', 'admin_word_values.admin_word_id')))
	->addCondition(array('open' => array()))
		->addCondition(array('where' => array('admin_word_values.admin_language_id', '=', CURRENT_LANGUAGE_ID)))
		->addCondition(array('setOr' => array()))
		->addCondition(array('where' => array('admin_forms.admin_word_id', '=', 0)))
	->addCondition(array('close' => array()));

if (strlen($sGlobalSearch))
{
	$oAdmin_Form_Dataset
		->addCondition(array('open' => array()));

	is_numeric($sGlobalSearch) && $oAdmin_Form_Dataset
			->addCondition(array('where' => array('admin_forms.id', '=', intval($sGlobalSearch))))
			->addCondition(array('setOr' => array()));

	$oAdmin_Form_Dataset
			->addCondition(array('where' => array('admin_forms.guid', '=', $sGlobalSearch)))
			->addCondition(array('setOr' => array()))
			->addCondition(array('where' => array('admin_word_values.name', 'LIKE', '%' . $sGlobalSearch . '%')))
		->addCondition(array('close' => array()));
		
	Core_Event::notify('Admin_Form_GlobalSearch.onAfterSetConditions', NULL, array($oAdmin_Form_Dataset, $sGlobalSearch));
}

// Добавляем источник данных контроллеру формы
$oAdmin_Form_Controller->addDataset(
	$oAdmin_Form_Dataset
);

// Показ формы
$oAdmin_Form_Controller->execute();